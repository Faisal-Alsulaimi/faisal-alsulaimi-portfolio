# Faisal Alsulaimi Portfolio — Vercel source export

This is the complete tracked source export from commit
`d7335812aceac45b22616113e8696d7e125dbc11`.

## Deploy to Vercel

1. Extract this ZIP.
2. Upload the contents of `Faisal-Alsulaimi-Portfolio` to a GitHub repository (keep `package.json` at the repository root).
3. In Vercel, add a project and import that repository.
4. Use the **Next.js** framework preset and **Node.js 22.x**. Keep the output directory at its framework default.
5. Deploy. `vercel.json` specifies the installation and build commands.

Alternatively, from the extracted project directory, run `npx vercel` and follow the prompts, then `npx vercel --prod` to publish.

## Run locally

With Node.js 22.x and pnpm 11.25.0 installed:

```sh
pnpm install --frozen-lockfile
pnpm dev
```

Production:

```sh
pnpm build
pnpm start
```

## Included

- Every tracked page, component, hook, stylesheet and animation.
- Portrait and project images in `public/`.
- All six original downloadable project files in `public/downloads/`.
- Full dependency declarations and the original `pnpm-lock.yaml`.
- Original Sites/Cloudflare support files, retained for completeness.
- Original versions of the four adjusted configuration/documentation files in `original-config/`.

Dependencies are installed from the manifest and lockfile; generated `node_modules`, caches, Git history and credentials are not included.

## Compatibility changes

Only deployment configuration was adapted: the dev/build/start commands now use standard Next.js, Node is set to 22.x, TypeScript includes the application rather than unused Cloudflare tooling, and the pnpm configuration no longer references a host-specific package cache. A Vercel configuration was added. Application code, components, styling, images, downloads and dependency versions were preserved.

The public portfolio requires no environment variables, database, ChatGPT sign-in or app connectors. Unused platform support files are retained but are not part of the portfolio's runtime.

Fonts continue to load from Google Fonts, exactly as in the original website; internet access is required for those fonts. LinkedIn remains an external link. The downloadable Aramco notebook retains its original separate dataset requirement.

The existing hosted website was not changed or redeployed. This export does not itself create a Vercel deployment.

References: https://vercel.com/docs/builds/configure-a-build and https://nextjs.org/docs/app/getting-started/deploying

## Validation

The standard Next.js production build and TypeScript checks passed. All tracked source files are included; application code, components and public assets were compared byte-for-byte against the original source. All referenced local images and downloads were found. No browser comparison or Vercel deployment was performed.
