import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {title:'فيصل السليمي | Faisal Alsulaimi',description:'Information Systems & Technology student. A portfolio of data analytics, dashboards and business projects.'};
export default function RootLayout({children}:Readonly<{children:React.ReactNode}>){return <html lang="ar" dir="rtl"><body>{children}</body></html>}
